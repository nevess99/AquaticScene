EECS 3431 ASSIGNMENT 1
Name: Neves Soares
Student#: 215782832

TASKS COMPLETED
(a) used real TIME to synchronize animations. 
(b) Ground Box
(c) Two rocks
(d) Seaweed modeling: each strand has 10 ellipses. 
(e) Seaweed animated
(f) Seaweed positioning
(g) Fish modeling: 2 eyes with pupils, 1 head, 1 body, 2 tail fins
(h) Fish animation: aligned with the tangent of the circle
(i) A burst of 4-5 bubbles appears every few seconds.
(j) Each bubble appears near the mouth of the character 
(k) The shape of each bubble oscillates with time. 
(l) Each bubble moves straight up with time. 
(m) Each bubble is removed/deleted after approximately 12 seconds.
(n) Model a human character with no arms.
(o) The character moves in the x and y world directions. 
(p) The legs of the character kick (hips, knees) as shown in the video.The feet do not move.
(q) my scene and the sample one are qualitatively and visually similar 
(r) Programming style (comments, functions) 
(s) The scene is 512x512.
(t) submission of "neves-soares.zip" is complete
(u) "readme.txt" file is complete